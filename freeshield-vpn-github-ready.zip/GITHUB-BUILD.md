# FreeShield VPN — GitHub APK Build

This repository includes a GitHub Actions workflow at:

`.github/workflows/build-apk.yml`

## Build from a phone

1. Create a GitHub repository and upload the **contents of this project**, including `.github`.
2. Push the files to `main` or `master`.
3. Open the repository's **Actions** tab.
4. Select **Build FreeShield VPN APK**.
5. Tap **Run workflow** if it is not already running.
6. When the job finishes, open the workflow run.
7. Download the **FreeShield-VPN-debug-APK** artifact.

The workflow builds a debug APK. It does not create a Play Store release/AAB and it does not sign a production release key.
